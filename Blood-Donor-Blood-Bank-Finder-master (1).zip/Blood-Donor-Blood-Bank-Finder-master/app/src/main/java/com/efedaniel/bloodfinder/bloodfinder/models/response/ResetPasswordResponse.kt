package com.efedaniel.bloodfinder.bloodfinder.models.response

data class ResetPasswordResponse(
    val email: String,
    val kind: String
)
