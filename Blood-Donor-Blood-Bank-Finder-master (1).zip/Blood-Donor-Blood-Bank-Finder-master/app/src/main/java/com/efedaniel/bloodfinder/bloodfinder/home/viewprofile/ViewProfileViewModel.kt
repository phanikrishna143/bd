package com.efedaniel.bloodfinder.bloodfinder.home.viewprofile

import com.efedaniel.bloodfinder.base.BaseViewModel
import javax.inject.Inject

class ViewProfileViewModel @Inject constructor() : BaseViewModel() {

    override fun addAllLiveDataToObservablesList() {
    }
}
