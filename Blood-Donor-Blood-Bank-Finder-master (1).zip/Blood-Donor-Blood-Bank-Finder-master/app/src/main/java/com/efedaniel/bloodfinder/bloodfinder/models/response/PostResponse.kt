package com.efedaniel.bloodfinder.bloodfinder.models.response

data class PostResponse(
    val name: String
)
